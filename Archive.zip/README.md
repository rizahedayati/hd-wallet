# HD wallet SDK with bip32,bip44,bip49 using js

# for test : 
    step 1 : clone repository
    step 2 : run npm install command
    step 3 : run node src/index.js command


Supported coin :
    BTC
    BTC_SEGWIT,
    ETH,
    MATIC,
    EOS,
    BNB,
    BSC,
    TRX,
    SOL,
    BCH,
    LTC,
    DOGE,
    DASH,
    QTUM,
    BTG,
    BTX,
    NEOS,
    RVN,
    XRP,
    THETA,
    XEC,
    DCR,
    LUNA,
    XEM,
    XLM,
    DOT,
    KSM,
    XTZ,
    MINA,
    ICX,
    ZEC,
    IOST,
    NEO,
    ZIL,
    KLAY,
    VET,
    WAVES,
    AVAX,
    AVAXC,
    FTM,
    CELO,
    FLOW,
    STX,
    HNT,
    XHB,
    FIL
